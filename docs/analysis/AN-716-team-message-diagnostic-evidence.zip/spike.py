import asyncio, gzip, hashlib, json, os, shutil, sys, time
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
import websockets

BASE = Path(__file__).resolve().parent
JAVA_HOME = Path('C:/Program Files/Eclipse Adoptium/jdk-25.0.1.8-hotspot')
ROOT = BASE / 'bots'
PORT = 38765
active = None

def prepare():
    team = ROOT / 'MyFirstTeam' / 'MyFirstTeam.json'
    data = json.loads(team.read_text())
    copy = dict(data)
    copy['name'] = 'MyFirstTeam-opponent'
    copy['teamMembers'] = []
    for name in data['teamMembers']:
        dest = ROOT / (name + '-opponent')
        if not dest.exists():
            shutil.copytree(ROOT / name, dest)
            for suffix in ('.cmd', '.json', '.sh'):
                src = dest / (name + suffix)
                if src.exists():
                    shutil.copyfile(src, dest / (dest.name + suffix))
                    if suffix != '.json':
                        src.unlink()
        copy['teamMembers'].append(dest.name)
    dest = ROOT / copy['name']
    dest.mkdir(exist_ok=True)
    (dest / (dest.name + '.json')).write_text(json.dumps(copy, indent=2))
    for name in data['teamMembers'] + copy['teamMembers']:
        script = ROOT / name / (name + '.cmd')
        original = script.with_suffix('.cmd.original')
        if not original.exists():
            shutil.copyfile(script, original)
        text = original.read_text()
        text = text.replace('"%BRIDGE_JAVA%" -cp',
            f'set "SERVER_URL=ws://127.0.0.1:{PORT}/?upstream=%SERVER_URL%&bot={name}"\n"%BRIDGE_JAVA%" -cp')
        text = text.replace('>nul', '>stdout.log 2>stderr.log')
        script.write_text(text)

async def proxy(bot):
    params = parse_qs(urlsplit(bot.request.path).query)
    name, upstream = params['bot'][0], params['upstream'][0]
    output = active
    async with websockets.connect(upstream, max_size=None, proxy=None) as server:
        async def relay(source, target, direction):
            try:
                async for message in source:
                    obj = json.loads(message)
                    kind = obj.get('type', '')
                    if 'handshake' not in kind.lower():
                        output.write(json.dumps({'bot': name, 'direction': direction, 'message': obj}) + '\n')
                    await target.send(message)
            except websockets.ConnectionClosed:
                pass
        tasks = [asyncio.create_task(relay(bot, server, 'intent')), asyncio.create_task(relay(server, bot, 'server'))]
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in tasks: task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

async def main():
    global active
    prepare()
    env = dict(os.environ, JAVA_HOME=str(JAVA_HOME))
    env['PATH'] = str(JAVA_HOME / 'bin') + os.pathsep + env['PATH']
    async with websockets.serve(proxy, '127.0.0.1', PORT, max_size=None):
        for number in range(int(sys.argv[1]), int(sys.argv[2]) + 1):
            out = BASE / f'run-{number:02}'
            out.mkdir(exist_ok=False)
            with gzip.open(out / 'bot-wire.jsonl.gz', 'wt', encoding='utf-8') as wire, (out / 'runner.log').open('w') as log:
                active = wire
                cmd = [str(JAVA_HOME / 'bin/java.exe'), '-cp', str(BASE / 'runner-1.4.0.jar'), str(BASE / 'TeamProbe.java'), str(ROOT), str(out)]
                if len(sys.argv) > 3: cmd.append(sys.argv[3])
                proc = await asyncio.create_subprocess_exec(*cmd, stdout=log, stderr=log, env=env)
                try: code = await asyncio.wait_for(proc.wait(), 180)
                except asyncio.TimeoutError:
                    proc.kill()
                    await proc.wait()
                    raise
                await asyncio.sleep(0.5)
                print(f'run={number} exit={code} result=' + ((out / 'results.txt').read_text() if (out / 'results.txt').exists() else 'missing'), flush=True)
                if code: break
                for folder in ROOT.iterdir():
                    if folder.is_dir():
                        for filename in ('stdout.log', 'stderr.log'):
                            p = folder / filename
                            if p.exists(): shutil.copyfile(p, out / (folder.name + '-' + filename))

asyncio.run(main())
