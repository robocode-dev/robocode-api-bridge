import collections, gzip, hashlib, json, pathlib, platform, subprocess, zipfile
BASE=pathlib.Path(__file__).resolve().parent
REPO=BASE.parent.parent
DEST=REPO/'docs/analysis'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'conditions':{'date':'2026-11-25','environment':'prepared','os':platform.platform(),
 'bridge_revision':'0f53ea6bb74e','java':'Temurin 25.0.1+8','python':platform.python_version(),
 'websockets':'15.0.1','runner_release':'1.4.0','runner_sha256':sha(BASE/'runner-1.4.0.jar'),
 'robot_source':'C:/Code/LiteRumble robots/teamrumble/sampleteam.MyFirstTeam_1.0.jar',
 'robot_sha256':sha(pathlib.Path('C:/Code/LiteRumble robots/teamrumble/sampleteam.MyFirstTeam_1.0.jar')),
 'staged_robot_sha256':sha(BASE/'source/sampleteam.MyFirstTeam_1.0.jar'),
 'archive_sha256':sha(REPO/'robots-wrapper/build/distributions/robocode-api-bridge-0.5.0-preview.g0f53ea6bb74e.zip'),
 'setup':{'rounds':1,'arenaWidth':800,'arenaHeight':600,'maxParticipants':10,'teams':2,'membersPerTeam':5,'turnTimeoutMicros':30000},
 'method':'Four fixed unmodified-bridge trials, one queue-logging trial, then two flush-before-move interventions. No estimate of failure frequency or Classic parity.'},'runs':[]}
for n in (1,2,3,4,6,7,8):
 p=BASE/f'run-{n:02}'
 bots={};obs=collections.Counter();deaths=[];observerEnd={}
 for line in gzip.open(p/'bot-wire.jsonl.gz','rt',encoding='utf-8'):
  d=json.loads(line);m=d['message'];kind=m['type'];name=d['bot']
  b=bots.setdefault(name,{'intentCount':0,'nonzeroIntents':collections.Counter(),'receivedEvents':collections.Counter(),'movingTicks':0,'queueSamples':[]})
  if kind=='GameStartedEventForBot':b.update(myId=m['myId'],teammateIds=m.get('teammateIds',[]))
  if kind=='BotIntent':
   b['intentCount']+=1
   for k in ('targetSpeed','turnRate','gunTurnRate','radarTurnRate','firepower','teamMessages'):
    if m.get(k):b['nonzeroIntents'][k]+=1
   for l in m.get('stdOut','').splitlines():
    if l.startswith('SPIKE_MOVE'):b['queueSamples'].append(l)
  if kind=='TickEventForBot':
   b.setdefault('firstState',m['botState']);b['lastState']=m['botState']
   b['movingTicks']+=bool(m['botState']['speed'])
   for e in m['events']:
    b['receivedEvents'][e['type']]+=1
    if e['type']=='ScannedBotEvent':
     key='teammateScans' if e['scannedBotId'] in b['teammateIds'] else 'enemyScans'
     b[key]=b.get(key,0)+1
  if kind=='RoundEndedEventForBot':b['roundEnded']=m
  if kind=='GameEndedEventForBot':b['gameEnded']=m
 for line in gzip.open(next(p.glob('*.battle.gz')),'rt',encoding='utf-8'):
  m=json.loads(line)
  if m['type']=='TickEventForObserver':
   for e in m['events']:
    obs[e['type']]+=1
    if e['type']=='BotDeathEvent':deaths.append(e)
  if m['type'] in ('RoundEndedEventForObserver','GameEndedEventForObserver'):observerEnd[m['type']]=m
 for b in bots.values():
  q=b['queueSamples']; b['queueSampleCount']=len(q);b['queueSamples']=q[:2]+q[-2:] if len(q)>4 else q
 report['runs'].append({'number':n,'variant':'original' if n<5 else ('queue logging' if n==6 else 'flush before move'),
   'observerEventCounts':obs,'deaths':deaths,'observerEnd':observerEnd,'bots':bots})
report['excluded_attempts']=[{'number':5,'reason':'Throwaway diagnostic attempted to subclass final BotPeer; leaders failed compilation, runner timed out with 8/10 bots. Not a bridge battle result.'}]
output=DEST/'AN-716-blocking-team-message-observations.json'
output.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
archive=DEST/'AN-716-team-message-diagnostic-evidence.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n in range(1,9):
  for p in sorted((BASE/f'run-{n:02}').glob('*')):
   if p.is_file():z.write(p,f'run-{n:02}/{p.name}')
 for name in ('TeamProbe.java','spike.py','summarize.py'):
  z.write(BASE/name,name)
 original=(REPO/'robocode-api/src/main/java/dev/robocode/tankroyale/bridge/BotPeer.java').read_text().splitlines(True)
 import difflib
 diagnostic=(BASE/'BotPeer.java').read_text().splitlines(True)
 z.writestr('diagnostic.patch',''.join(difflib.unified_diff(original,diagnostic,fromfile='BotPeer.java',tofile='BotPeer.java')))
 z.writestr('REPRODUCE.txt', '''Prepared-environment experiment, not an installation walkthrough.
Use bridge revision 0f53ea6bb74e, Temurin JDK 25.0.1+8, Python 3.14 and websockets 15.0.1 on Windows.
Build :robots-wrapper:previewDist, unpack it into package/, copy the unchanged sampleteam.MyFirstTeam_1.0.jar into source/ and import into bots/ with wrap-robots --output.
Obtain published runner 1.4.0 as runner-1.4.0.jar; verify SHA256 02f6d1d8e9346a4aeae1b91e7abb278c98ac1f1d30c605f867758566f5f327cf.
Place TeamProbe.java and spike.py beside bots/. Adapt the Java path only if needed. Run python spike.py 1 4.
For the queue experiment, copy BotPeer.java from the pinned bridge source, apply diagnostic.patch, compile with javac --release 11 -cp <robots-wrapper fat jar> -d diagnostic-classes BotPeer.java.
Add ../../diagnostic-classes; at the front of the classpath in every member's .cmd.original (created by spike.py).
Run python spike.py 6 6 with SPIKE_FLUSH absent. Then set SPIKE_FLUSH=true and run python spike.py 7 8.
Run 5 is an excluded failed attempt to subclass final BotPeer; its failure logs are retained for chronology and it is not used as battle evidence.
The proxy relays messages unchanged and excludes handshakes from capture. Recordings contain observer events; bot-wire.jsonl.gz contains per-bot intents and results. Original rumble jars are never edited.
The intervention flushes only at move entry and is not a complete turn-boundary repair. Starting positions are nondeterministic; results are not a failure-rate or parity estimate.
''')
print('summary',output.stat().st_size,'archive',archive.stat().st_size,'archive_sha256',sha(archive))
for r in report['runs']:
 print(r['number'],r['variant'],'events',dict(r['observerEventCounts']), 'teamMessages',sum(b['nonzeroIntents']['teamMessages'] for b in r['bots'].values()),'ranks/scores',[(x['rank'],x['totalScore']) for x in r['observerEnd']['GameEndedEventForObserver']['results']])
