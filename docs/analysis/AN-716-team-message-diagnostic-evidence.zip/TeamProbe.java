import dev.robocode.tankroyale.runner.*;
import java.nio.file.*;
import java.util.*;

public class TeamProbe {
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]), out = Path.of(args[1]);
        Files.createDirectories(out);
        try (BattleRunner runner = BattleRunner.create(b -> b.embeddedServer().enableRecording(out))) {
            BattleSetup setup = BattleSetup.classic(s -> {
                s.setNumberOfRounds(1);
                s.setArenaWidth(800);
                s.setArenaHeight(600);
                s.setMaxNumberOfParticipants(10);
                if (args.length > 2) s.setTurnTimeoutMicros(Integer.parseInt(args[2]));
            });
            BattleResults result = runner.runBattle(setup, List.of(
                BotEntry.of(root.resolve("MyFirstTeam")), BotEntry.of(root.resolve("MyFirstTeam-opponent"))));
            Files.writeString(out.resolve("results.txt"), result.toString());
            System.out.println("RESULT " + result);
        }
    }
}
